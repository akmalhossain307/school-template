function myFunction1920En() {
    var dots = document.getElementById("dots-1920-en");
    var moreText = document.getElementById("more-1920-en");
    var btnText = document.getElementById("myBtn-1920-en");

    if (dots.style.display === "none") {
        dots.style.display = "inline";
        btnText.innerHTML = "Read more";
        moreText.style.display = "none";
    } else {
        dots.style.display = "none";
        btnText.style.display = "none";
        moreText.style.display = "inline";
    }
}

function myFunction1939En() {
    var dots = document.getElementById("dots-1939-en");
    var moreText = document.getElementById("more-1939-en");
    var btnText = document.getElementById("myBtn-1939-en");

    if (dots.style.display === "none") {
        dots.style.display = "inline";
        btnText.innerHTML = "Read more";
        moreText.style.display = "none";
    } else {
        dots.style.display = "none";
        btnText.style.display = "none";
        moreText.style.display = "inline";
    }
}

function myFunction1942En() {
    var dots = document.getElementById("dots-1942-en");
    var moreText = document.getElementById("more-1942-en");
    var btnText = document.getElementById("myBtn-1942-en");

    if (dots.style.display === "none") {
        dots.style.display = "inline";
        btnText.innerHTML = "Read more";
        moreText.style.display = "none";
    } else {
        dots.style.display = "none";
        btnText.style.display = "none";
        moreText.style.display = "inline";
    }
}

function myFunction1943En() {
    var dots = document.getElementById("dots-1943-en");
    var moreText = document.getElementById("more-1943-en");
    var btnText = document.getElementById("myBtn-1943-en");

    if (dots.style.display === "none") {
        dots.style.display = "inline";
        btnText.innerHTML = "Read more";
        moreText.style.display = "none";
    } else {
        dots.style.display = "none";
        btnText.style.display = "none";
        moreText.style.display = "inline";
    }
}

function myFunction1946En() {
    var dots = document.getElementById("dots-1946-en");
    var moreText = document.getElementById("more-1946-en");
    var btnText = document.getElementById("myBtn-1946-en");

    if (dots.style.display === "none") {
        dots.style.display = "inline";
        btnText.innerHTML = "Read more";
        moreText.style.display = "none";
    } else {
        dots.style.display = "none";
        btnText.style.display = "none";
        moreText.style.display = "inline";
    }
}

function myFunction1947En() {
    var dots = document.getElementById("dots-1947-en");
    var moreText = document.getElementById("more-1947-en");
    var btnText = document.getElementById("myBtn-1947-en");

    if (dots.style.display === "none") {
        dots.style.display = "inline";
        btnText.innerHTML = "Read more";
        moreText.style.display = "none";
    } else {
        dots.style.display = "none";
        btnText.style.display = "none";
        moreText.style.display = "inline";
    }
}

function myFunction1948En() {
    var dots = document.getElementById("dots-1948-en");
    var moreText = document.getElementById("more-1948-en");
    var btnText = document.getElementById("myBtn-1948-en");

    if (dots.style.display === "none") {
        dots.style.display = "inline";
        btnText.innerHTML = "Read more";
        moreText.style.display = "none";
    } else {
        dots.style.display = "none";
        btnText.style.display = "none";
        moreText.style.display = "inline";
    }
}

function myFunction1949En() {
    var dots = document.getElementById("dots-1949-en");
    var moreText = document.getElementById("more-1949-en");
    var btnText = document.getElementById("myBtn-1949-en");

    if (dots.style.display === "none") {
        dots.style.display = "inline";
        btnText.innerHTML = "Read more";
        moreText.style.display = "none";
    } else {
        dots.style.display = "none";
        btnText.style.display = "none";
        moreText.style.display = "inline";
    }
}

function myFunction1952En() {
    var dots = document.getElementById("dots-1952-en");
    var moreText = document.getElementById("more-1952-en");
    var btnText = document.getElementById("myBtn-1952-en");

    if (dots.style.display === "none") {
        dots.style.display = "inline";
        btnText.innerHTML = "Read more";
        moreText.style.display = "none";
    } else {
        dots.style.display = "none";
        btnText.style.display = "none";
        moreText.style.display = "inline";
    }
}

function myFunction1954En() {
    var dots = document.getElementById("dots-1954-en");
    var moreText = document.getElementById("more-1954-en");
    var btnText = document.getElementById("myBtn-1954-en");

    if (dots.style.display === "none") {
        dots.style.display = "inline";
        btnText.innerHTML = "Read more";
        moreText.style.display = "none";
    } else {
        dots.style.display = "none";
        btnText.style.display = "none";
        moreText.style.display = "inline";
    }
}

function myFunction1956En() {
    var dots = document.getElementById("dots-1956-en");
    var moreText = document.getElementById("more-1956-en");
    var btnText = document.getElementById("myBtn-1956-en");

    if (dots.style.display === "none") {
        dots.style.display = "inline";
        btnText.innerHTML = "Read more";
        moreText.style.display = "none";
    } else {
        dots.style.display = "none";
        btnText.style.display = "none";
        moreText.style.display = "inline";
    }
}


function myFunction1962En() {
    var dots = document.getElementById("dots-1962-en");
    var moreText = document.getElementById("more-1962-en");
    var btnText = document.getElementById("myBtn-1962-en");

    if (dots.style.display === "none") {
        dots.style.display = "inline";
        btnText.innerHTML = "Read more";
        moreText.style.display = "none";
    } else {
        dots.style.display = "none";
        btnText.style.display = "none";
        moreText.style.display = "inline";
    }
}


function myFunction1964En() {
    var dots = document.getElementById("dots-1964-en");
    var moreText = document.getElementById("more-1964-en");
    var btnText = document.getElementById("myBtn-1964-en");

    if (dots.style.display === "none") {
        dots.style.display = "inline";
        btnText.innerHTML = "Read more";
        moreText.style.display = "none";
    } else {
        dots.style.display = "none";
        btnText.style.display = "none";
        moreText.style.display = "inline";
    }
}


function myFunction1966En() {
    var dots = document.getElementById("dots-1966-en");
    var moreText = document.getElementById("more-1966-en");
    var btnText = document.getElementById("myBtn-1966-en");

    if (dots.style.display === "none") {
        dots.style.display = "inline";
        btnText.innerHTML = "Read more";
        moreText.style.display = "none";
    } else {
        dots.style.display = "none";
        btnText.style.display = "none";
        moreText.style.display = "inline";
    }
}


function myFunction1968En() {
    var dots = document.getElementById("dots-1968-en");
    var moreText = document.getElementById("more-1968-en");
    var btnText = document.getElementById("myBtn-1968-en");

    if (dots.style.display === "none") {
        dots.style.display = "inline";
        btnText.innerHTML = "Read more";
        moreText.style.display = "none";
    } else {
        dots.style.display = "none";
        btnText.style.display = "none";
        moreText.style.display = "inline";
    }
}



function myFunction1969En() {
    var dots = document.getElementById("dots-1969-en");
    var moreText = document.getElementById("more-1969-en");
    var btnText = document.getElementById("myBtn-1969-en");

    if (dots.style.display === "none") {
        dots.style.display = "inline";
        btnText.innerHTML = "Read more";
        moreText.style.display = "none";
    } else {
        dots.style.display = "none";
        btnText.style.display = "none";
        moreText.style.display = "inline";
    }
}



function myFunction1970En() {
    var dots = document.getElementById("dots-1970-en");
    var moreText = document.getElementById("more-1970-en");
    var btnText = document.getElementById("myBtn-1970-en");

    if (dots.style.display === "none") {
        dots.style.display = "inline";
        btnText.innerHTML = "Read more";
        moreText.style.display = "none";
    } else {
        dots.style.display = "none";
        btnText.style.display = "none";
        moreText.style.display = "inline";
    }
}

function myFunction1971En() {
    var dots = document.getElementById("dots-1971-en");
    var moreText = document.getElementById("more-1971-en");
    var btnText = document.getElementById("myBtn-1971-en");

    if (dots.style.display === "none") {
        dots.style.display = "inline";
        btnText.innerHTML = "Read more";
        moreText.style.display = "none";
    } else {
        dots.style.display = "none";
        btnText.style.display = "none";
        moreText.style.display = "inline";
    }
}

function myFunction1972En() {
    var dots = document.getElementById("dots-1972-en");
    var moreText = document.getElementById("more-1972-en");
    var btnText = document.getElementById("myBtn-1972-en");

    if (dots.style.display === "none") {
        dots.style.display = "inline";
        btnText.innerHTML = "Read more";
        moreText.style.display = "none";
    } else {
        dots.style.display = "none";
        btnText.style.display = "none";
        moreText.style.display = "inline";
    }
}

function myFunction1974En() {
    var dots = document.getElementById("dots-1974-en");
    var moreText = document.getElementById("more-1974-en");
    var btnText = document.getElementById("myBtn-1974-en");

    if (dots.style.display === "none") {
        dots.style.display = "inline";
        btnText.innerHTML = "Read more";
        moreText.style.display = "none";
    } else {
        dots.style.display = "none";
        btnText.style.display = "none";
        moreText.style.display = "inline";
    }
}

function myFunction1975En() {
    var dots = document.getElementById("dots-1975-en");
    var moreText = document.getElementById("more-1975-en");
    var btnText = document.getElementById("myBtn-1975-en");

    if (dots.style.display === "none") {
        dots.style.display = "inline";
        btnText.innerHTML = "Read more";
        moreText.style.display = "none";
    } else {
        dots.style.display = "none";
        btnText.style.display = "none";
        moreText.style.display = "inline";
    }
}

















function myFunction1920Bn() {
    var dots = document.getElementById("dots-1920-bn");
    var moreText = document.getElementById("more-1920-bn");
    var btnText = document.getElementById("myBtn-1920-bn");

    if (dots.style.display === "none") {
        dots.style.display = "inline";
        btnText.innerHTML = "Read more";
        moreText.style.display = "none";
    } else {
        dots.style.display = "none";
        btnText.style.display = "none";
        moreText.style.display = "inline";
    }
}

function myFunction1939Bn() {
    var dots = document.getElementById("dots-1939-bn");
    var moreText = document.getElementById("more-1939-bn");
    var btnText = document.getElementById("myBtn-1939-bn");

    if (dots.style.display === "none") {
        dots.style.display = "inline";
        btnText.innerHTML = "Read more";
        moreText.style.display = "none";
    } else {
        dots.style.display = "none";
        btnText.style.display = "none";
        moreText.style.display = "inline";
    }
}

function myFunction1946Bn() {
    var dots = document.getElementById("dots-1946-bn");
    var moreText = document.getElementById("more-1946-bn");
    var btnText = document.getElementById("myBtn-1946-bn");

    if (dots.style.display === "none") {
        dots.style.display = "inline";
        btnText.innerHTML = "Read more";
        moreText.style.display = "none";
    } else {
        dots.style.display = "none";
        btnText.style.display = "none";
        moreText.style.display = "inline";
    }
}

function myFunction1948Bn() {
    var dots = document.getElementById("dots-1948-bn");
    var moreText = document.getElementById("more-1948-bn");
    var btnText = document.getElementById("myBtn-1948-bn");

    if (dots.style.display === "none") {
        dots.style.display = "inline";
        btnText.innerHTML = "Read more";
        moreText.style.display = "none";
    } else {
        dots.style.display = "none";
        btnText.style.display = "none";
        moreText.style.display = "inline";
    }
}

function myFunction1949Bn() {
    var dots = document.getElementById("dots-1949-bn");
    var moreText = document.getElementById("more-1949-bn");
    var btnText = document.getElementById("myBtn-1949-bn");

    if (dots.style.display === "none") {
        dots.style.display = "inline";
        btnText.innerHTML = "Read more";
        moreText.style.display = "none";
    } else {
        dots.style.display = "none";
        btnText.style.display = "none";
        moreText.style.display = "inline";
    }
}

function myFunction1952Bn() {
    var dots = document.getElementById("dots-1952-bn");
    var moreText = document.getElementById("more-1952-bn");
    var btnText = document.getElementById("myBtn-1952-bn");

    if (dots.style.display === "none") {
        dots.style.display = "inline";
        btnText.innerHTML = "Read more";
        moreText.style.display = "none";
    } else {
        dots.style.display = "none";
        btnText.style.display = "none";
        moreText.style.display = "inline";
    }
}

function myFunction1954Bn() {
    var dots = document.getElementById("dots-1954-bn");
    var moreText = document.getElementById("more-1954-bn");
    var btnText = document.getElementById("myBtn-1954-bn");

    if (dots.style.display === "none") {
        dots.style.display = "inline";
        btnText.innerHTML = "Read more";
        moreText.style.display = "none";
    } else {
        dots.style.display = "none";
        btnText.style.display = "none";
        moreText.style.display = "inline";
    }
}

function myFunction1956Bn() {
    var dots = document.getElementById("dots-1956-bn");
    var moreText = document.getElementById("more-1956-bn");
    var btnText = document.getElementById("myBtn-1956-bn");

    if (dots.style.display === "none") {
        dots.style.display = "inline";
        btnText.innerHTML = "Read more";
        moreText.style.display = "none";
    } else {
        dots.style.display = "none";
        btnText.style.display = "none";
        moreText.style.display = "inline";
    }
}


function myFunction1962Bn() {
    var dots = document.getElementById("dots-1962-bn");
    var moreText = document.getElementById("more-1962-bn");
    var btnText = document.getElementById("myBtn-1962-bn");

    if (dots.style.display === "none") {
        dots.style.display = "inline";
        btnText.innerHTML = "Read more";
        moreText.style.display = "none";
    } else {
        dots.style.display = "none";
        btnText.style.display = "none";
        moreText.style.display = "inline";
    }
}

function myFunction1964Bn() {
    var dots = document.getElementById("dots-1964-bn");
    var moreText = document.getElementById("more-1964-bn");
    var btnText = document.getElementById("myBtn-1964-bn");

    if (dots.style.display === "none") {
        dots.style.display = "inline";
        btnText.innerHTML = "Read more";
        moreText.style.display = "none";
    } else {
        dots.style.display = "none";
        btnText.style.display = "none";
        moreText.style.display = "inline";
    }
}


function myFunction1966Bn() {
    var dots = document.getElementById("dots-1966-bn");
    var moreText = document.getElementById("more-1966-bn");
    var btnText = document.getElementById("myBtn-1966-bn");

    if (dots.style.display === "none") {
        dots.style.display = "inline";
        btnText.innerHTML = "Read more";
        moreText.style.display = "none";
    } else {
        dots.style.display = "none";
        btnText.style.display = "none";
        moreText.style.display = "inline";
    }
}


function myFunction1968Bn() {
    var dots = document.getElementById("dots-1968-bn");
    var moreText = document.getElementById("more-1968-bn");
    var btnText = document.getElementById("myBtn-1968-bn");

    if (dots.style.display === "none") {
        dots.style.display = "inline";
        btnText.innerHTML = "Read more";
        moreText.style.display = "none";
    } else {
        dots.style.display = "none";
        btnText.style.display = "none";
        moreText.style.display = "inline";
    }
}



function myFunction1969Bn() {
    var dots = document.getElementById("dots-1969-bn");
    var moreText = document.getElementById("more-1969-bn");
    var btnText = document.getElementById("myBtn-1969-bn");

    if (dots.style.display === "none") {
        dots.style.display = "inline";
        btnText.innerHTML = "Read more";
        moreText.style.display = "none";
    } else {
        dots.style.display = "none";
        btnText.style.display = "none";
        moreText.style.display = "inline";
    }
}



function myFunction1970Bn() {
    var dots = document.getElementById("dots-1970-bn");
    var moreText = document.getElementById("more-1970-bn");
    var btnText = document.getElementById("myBtn-1970-bn");

    if (dots.style.display === "none") {
        dots.style.display = "inline";
        btnText.innerHTML = "Read more";
        moreText.style.display = "none";
    } else {
        dots.style.display = "none";
        btnText.style.display = "none";
        moreText.style.display = "inline";
    }
}

function myFunction1971Bn() {
    var dots = document.getElementById("dots-1971-bn");
    var moreText = document.getElementById("more-1971-bn");
    var btnText = document.getElementById("myBtn-1971-bn");

    if (dots.style.display === "none") {
        dots.style.display = "inline";
        btnText.innerHTML = "Read more";
        moreText.style.display = "none";
    } else {
        dots.style.display = "none";
        btnText.style.display = "none";
        moreText.style.display = "inline";
    }
}

function myFunction1972Bn() {
    var dots = document.getElementById("dots-1972-bn");
    var moreText = document.getElementById("more-1972-bn");
    var btnText = document.getElementById("myBtn-1972-bn");

    if (dots.style.display === "none") {
        dots.style.display = "inline";
        btnText.innerHTML = "Read more";
        moreText.style.display = "none";
    } else {
        dots.style.display = "none";
        btnText.style.display = "none";
        moreText.style.display = "inline";
    }
}

function myFunction1974Bn() {
    var dots = document.getElementById("dots-1974-bn");
    var moreText = document.getElementById("more-1974-bn");
    var btnText = document.getElementById("myBtn-1974-bn");

    if (dots.style.display === "none") {
        dots.style.display = "inline";
        btnText.innerHTML = "Read more";
        moreText.style.display = "none";
    } else {
        dots.style.display = "none";
        btnText.style.display = "none";
        moreText.style.display = "inline";
    }
}

function myFunction1975Bn() {
    var dots = document.getElementById("dots-1975-bn");
    var moreText = document.getElementById("more-1975-bn");
    var btnText = document.getElementById("myBtn-1975-bn");

    if (dots.style.display === "none") {
        dots.style.display = "inline";
        btnText.innerHTML = "Read more";
        moreText.style.display = "none";
    } else {
        dots.style.display = "none";
        btnText.style.display = "none";
        moreText.style.display = "inline";
    }
}